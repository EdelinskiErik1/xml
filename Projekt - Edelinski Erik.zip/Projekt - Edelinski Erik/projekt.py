import xml.etree.ElementTree as ET


tree = ET.parse('pokemoni.xml.txt')
root = tree.getroot()

def upit():
    val = int(input("[ (0)Ispisite pokemone, (1)Unesite novog pokemona, (2)Izbrišite pokemona] "))
    return(val)

def akcije(val):
    if val == 0:
        for pokemon in root.iter('pokemon'):
            ide = pokemon.find('id').text
            ime = pokemon.find('name').text
            tip = pokemon.find('type').text
            print("Id: {}\n Name: {}\n Type: {}\n\n ".format(ide, ime, tip))
            
            
            
    if val == 1 :
        ide = str(input("Id: "))
        ime = str(input("Name: "))
        tip = str(input("Type: "))
        num = 0

        for pokemon in root.iter('pokemon'):
            num = num+1
        
        pokemon = ET.SubElement(root, 'pokemon')
        pokemon.set('id', '4')
        
        ET.SubElement(root[num], 'id')
        for temp in root[num].iter('id'):
            temp.text = ide
        ET.SubElement(root[num], 'name')
        for temp in root[num].iter('name'):
            temp.text = ime
        ET.SubElement(root[num], 'type')
        for temp in root[num].iter('type'):
            temp.text = tip
      

        tree.write('pokemoni.xml.txt')
        

        
    if val == 2:
        num = 0

        for pokemon in root.iter('pokemon'):
            num = num+1
        num = num-1
        print("Izbrišite pokemona (0 - {})".format(num))
        num1 = int(input(" "))
        root.remove(root[num])
        tree.write('pokemoni.xml.txt')
        
        

def main():
    while(1):
        val = upit()
        akcije(val)
    

main()
